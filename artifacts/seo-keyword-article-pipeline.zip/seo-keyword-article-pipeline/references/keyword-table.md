# Keyword Table Contract

## Recommended columns

| Column | Required | Meaning |
|---|---:|---|
| `primaryKeyword` | yes | One page-level keyword target |
| `priority` | no | Lower numbers run first; row order is the fallback |
| `slug` | no | Generated from the primary keyword when absent |
| `category` | no | Site taxonomy |
| `intent` | no | `informational`, `tutorial`, `comparison`, `commercial`, or another explicit project value |
| `supportingKeywords` | no | 3-5 values separated with `|` or `;` |
| `requiredAngles` | no | Required subtopics separated with `|` or `;` |
| `parentPillar` | no | Existing pillar or hub route |
| `contentFormat` | no | Explicit format; otherwise inferred from intent and page type |
| `formatReason` | no | Why the selected format matches the query |
| `funnelStage` | no | `TOFU`, `MOFU`, or `BOFU` |
| `conversionGoal` | no | Reader outcome or primary action |
| `requiredModules` | no | Format-specific modules separated with `|` or `;` |
| `visualRequirement` | no | `required`, `recommended`, `optional`, or `not_applicable` |
| `variantDimensions` | no | Distinct dimensions for scalable page families |
| `status` | no | Defaults to `queued` |
| `id` | no | Generated as `<site-id>-NNN` when absent |

The importer accepts common aliases such as `keyword`, `primary_keyword`, `search_intent`, `secondary_keywords`, and `required_angles`.

When a strategy export contains `Page`, `Topic`, `Page type`, `Volume`, and
`Keyword`, grouping is automatic: one task is created per `Page`. The highest-
volume keyword in each group becomes the primary keyword; the next five become
supporting keywords, and seed keywords become required angles. The importer also
infers a reviewable content format, funnel stage, conversion goal, and optional
visual requirement; explicit values in the table win. Existing tasks are
enriched by matching their primary keyword or target page instead of being
duplicated, while an existing task's explicit intent remains authoritative.

## Supported files

- CSV
- TSV
- JSON array
- JSON object containing a `tasks` array

For XLSX, inspect the workbook and export the intended worksheet to CSV first. Confirm headers, formulas, hidden rows, and merged cells before conversion.

## Import

```bash
python3 scripts/import_keywords.py keywords.csv \
  --output content-pipeline/tasks.json \
  --site-id example
```

For a scoped MLB strategy export, apply the site's topic and term filters:

```bash
python3 scripts/import_keywords.py keywords.csv \
  --output content-pipeline/tasks.json \
  --existing content-pipeline/tasks.json \
  --site-id strategy \
  --group-by-page \
  --exclude-topic "mlb betting odds & analysis" \
  --exclude-term nba --exclude-term nfl --exclude-term nhl \
  --exclude-term parlay --exclude-term gambling --exclude-term sportsbook \
  --exclude-term betting --exclude-term odds
```

Merge with an existing task file:

```bash
python3 scripts/import_keywords.py keywords.csv \
  --output content-pipeline/tasks.json \
  --site-id example \
  --existing content-pipeline/tasks.json
```

The importer rejects duplicate primary keywords, slugs, IDs, and rows without a keyword. It preserves existing tasks during a merge and appends only new unique tasks.

## Planning rules

After import, do not publish directly from volume or search-volume ranking alone. Review:

1. exact keyword duplicates;
2. near-duplicate language and shared entities;
3. search intent overlap;
4. whether an existing article can satisfy the query with a small update;
5. whether two keywords should be grouped into one page;
6. whether one broad keyword should be split into distinct pages.

Record the decision in `contentDifferentiation` before drafting.

## Format routing

Use the query's intent and page type to choose a format before drafting:

| Signal | Default format | Required proof |
|---|---|---|
| Informational question | `deep_explanation` | direct answer, original analysis, limitations |
| Tutorial/how-to intent | `how_to` | prerequisites, ordered steps, expected result, troubleshooting |
| Explicit comparison/alternatives | `comparison` | consistent criteria, table, fit-based verdict |
| Commercial selection | `structured_recommendation` | selection criteria and sourced rationale |
| Review intent | `review` | disclosed method and first-hand evidence |
| Tool/template/optimizer page | `tool_landing_page` | use cases, examples, CTA, unique variant dimensions |

Treat community observations such as “best listicles are declining” or fixed
conversion rankings as hypotheses to test against the actual SERP and analytics,
not as universal validator rules. Google does not specify a preferred word count.
