# Article Contract

Use this contract for new strict articles. Adapt field names to the target CMS while preserving the checks.

## Required identity and metadata

- `schemaVersion`
- `seoAuditVersion: 2`
- `status`: `draft`, `review`, or `approved`
- `slug`: lowercase kebab-case
- `category`
- `primaryKeyword`: exactly one page-level target
- `primaryKeywordVariants`: optional natural grammatical forms approved for placement checks
- `supportingKeywords`: 3-5 closely related terms
- `intent`: one primary reader intent
- `contentFormat`: one of `deep_explanation`, `how_to`, `comparison`, `review`, `structured_recommendation`, `tool_landing_page`, or `product_use_case`
- `formatReason`: a specific explanation of why the format matches the intent and page type
- `funnelStage`: `TOFU`, `MOFU`, or `BOFU`
- `conversionGoal`: the reader outcome, such as `learn_and_apply` or `start_optimizer`
- `requiredModules`: format-specific modules selected by the brief
- `visualRequirement`: `required`, `recommended`, `optional`, or `not_applicable`
- `variantDimensions`: dimensions that make a programmatic page materially distinct
- `contentDifferentiation`: at least one specific sentence distinguishing this page from existing content
- `uniqueValue`: at least one specific sentence describing original evidence, analysis, method, or examples
- `title`, `description`, `excerpt`, `author`, `reviewer`, `updatedAt`
- `publishedAt` when approved

## Default deterministic gates

- Title: 35-65 characters and includes the primary keyword.
- Meta description: 120-165 characters.
- Body: at least 800 words.
- Primary-keyword density: no more than 3% exact-phrase occurrences.
- Primary keyword or an approved variant: title, opening 100 words, at least one section heading, and final conclusion.
- Supporting keywords: every declared term appears naturally at least once.
- Structure: at least 4 sections, 3 FAQ items, 2 internal links, one limitations/verification section, and an explicit conclusion or next-steps final section.
- Format fit: strict articles must pass the conditional module checks for their `contentFormat`; FAQs and visual assets are intent-dependent, not universal ranking requirements.
- Format-specific evidence: `how_to` needs prerequisites, 3+ ordered steps, expected outcomes, and troubleshooting; `comparison` needs 2+ compared items, 2+ criteria, and a fit-based verdict; `review` needs a disclosed method and first-hand evidence; `structured_recommendation` needs 2+ selection criteria and 2+ recommendations; `tool_landing_page` needs 2+ use cases, examples, variant dimensions, and a CTA.
- Programmatic uniqueness: pages in a template family must declare at least one variant dimension and a unique value statement; changing only the keyword or location is insufficient.
- Sources: at least 2, including at least 1 primary source; every source has ID, title, publisher, URL, access date, and type.
- Evidence: every section has source IDs. Every non-fictional claim-ledger entry has valid source IDs and a check date.
- Numeric claims: every number in factual body copy appears in the claim ledger. Clearly labeled fictional or illustrative paragraphs are exempt.
- Publication: approved articles require a publication date and named reviewer.
- Blocked topics: hard failure, not a warning.
- Project-required disclosures: exact reader-facing statements must appear in strict articles.

Projects may tighten these limits. Do not silently weaken them to make a draft pass.

## Claim ledger

Use entries shaped like:

```json
{
  "claim": "The platform currently allows 20 exports per day.",
  "type": "numeric",
  "action": "verified",
  "sourceIds": ["product-page"],
  "checkedAt": "2026-08-04"
}
```

Allowed types: `factual`, `numeric`, `time-sensitive`, `fictional`.

Allowed actions: `verified`, `softened`, `removed`, `fictional`.

Entries marked `removed` need a check date but no supporting source because the unsupported claim must not remain in published copy.

A fictional entry must use both `type: fictional` and `action: fictional`. Label the corresponding article example as fictional, illustrative, or invented.

## Editorial audit

Record:

```json
{
  "searchIntent": "pass",
  "contentDepth": "pass",
  "factCheck": "pass",
  "humanization": "pass",
  "auditedAt": "2026-08-04",
  "notes": "Specific description of the audit and post-edit integrity check."
}
```

Do not mark a field `pass` merely because deterministic validation succeeded.

### Search intent

- One reader question is answered throughout.
- Title, opening, headings, FAQ, and conclusion share the same purpose.
- `contentDifferentiation` explains why existing pages do not already satisfy the query.
- `contentFormat` and `funnelStage` fit the query, page type, and desired reader outcome.

### Content depth

- Sections lead with a practical answer.
- Explanations include concrete steps, criteria, examples, trade-offs, or limitations.
- FAQ questions reflect likely follow-up intent instead of repeating the conclusion.

### Fact check

- Objective and volatile claims are verified with current authoritative evidence.
- Unsupported claims are softened or removed.
- Sources support the actual claim, not merely the broad topic.

### Humanization

- Remove filler, repeated definitions, vague attribution, inflated significance, uniform cadence, forced symmetry, generic conclusions, and chatbot artifacts.
- Preserve facts, certainty, citations, URLs, technical tokens, keywords, and CTAs.
- Recheck every element changed during the style pass.

### Format audit

- Do not treat anecdotal format rankings, fixed word counts, or a universal “best list” rule as Google requirements.
- A recommendation or review must disclose selection/testing criteria and preserve evidence for every factual comparison.
- A testimonial, user quote, screenshot, or first-hand claim requires a real source or an explicitly labeled illustration.
- Batch-generated pages must carry different examples, entities, or decision criteria that remain useful even if the primary keyword is removed.

## Rendered verification

After the production build, inspect the real output rather than source code alone:

- HTTP or static artifact exists.
- Exactly one H1.
- Correct canonical URL.
- Approved article is indexable and does not contain `noindex`.
- Article and breadcrumb structured data exist.
- FAQ structured data exists when the FAQ is rendered on the page.
- Internal links and CTA resolve to intended routes.
