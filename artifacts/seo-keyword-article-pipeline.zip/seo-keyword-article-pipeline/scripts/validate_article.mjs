#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const scriptDir = path.dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  if (!argv[0] || argv.includes("--help")) {
    console.log("Usage: validate_article.mjs <article.json> [--config gates.json] [--existing-dir DIR] [--check-urls] [--rendered-html FILE] [--canonical URL]");
    process.exit(argv.includes("--help") ? 0 : 2);
  }
  const options = {
    article: path.resolve(argv[0]),
    config: path.resolve(scriptDir, "../references/quality-gates.example.json"),
    existingDir: null,
    checkUrls: false,
    renderedHtml: null,
    canonical: null,
  };
  for (let index = 1; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--check-urls") options.checkUrls = true;
    else if (arg === "--config") options.config = path.resolve(argv[++index]);
    else if (arg === "--existing-dir") options.existingDir = path.resolve(argv[++index]);
    else if (arg === "--rendered-html") options.renderedHtml = path.resolve(argv[++index]);
    else if (arg === "--canonical") options.canonical = argv[++index];
    else throw new Error(`Unknown argument: ${arg}`);
  }
  return options;
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function words(value) {
  return String(value || "").trim().split(/\s+/).filter(Boolean);
}

function normalize(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[’']/g, "'")
    .replace(/[^a-z0-9'\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function includesPhrase(value, phrase) {
  const target = normalize(phrase);
  return Boolean(target) && normalize(value).includes(target);
}

function keywordForms(article) {
  return [article.primaryKeyword, ...(article.primaryKeywordVariants || [])].filter(Boolean);
}

function includesKeywordForm(value, article) {
  return keywordForms(article).some((form) => includesPhrase(value, form));
}

function bodyText(article) {
  return [
    article.excerpt,
    ...(article.keyTakeaways || []),
    ...(article.sections || []).flatMap((section) => [section.heading, ...(section.paragraphs || [])]),
    ...(article.faq || []).flatMap((item) => [item.question, item.answer]),
  ].join(" ");
}

function openingText(article, count) {
  return words([
    article.excerpt,
    ...(article.keyTakeaways || []),
    ...(article.sections?.[0]?.paragraphs || []),
  ].join(" ")).slice(0, count).join(" ");
}

function hostname(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

function numericTokens(value) {
  return String(value || "").match(/\b\d+(?:\.\d+)?%?\b/g) || [];
}

function loadExisting(directory) {
  if (!directory || !fs.existsSync(directory)) return [];
  return fs
    .readdirSync(directory)
    .filter((file) => file.endsWith(".json"))
    .map((file) => readJson(path.join(directory, file)));
}

function nonEmptyStrings(value) {
  return Array.isArray(value) && value.every((item) => String(item || "").trim().length > 0);
}

function validateFormat(article, seo, errors) {
  const allowedFormats = new Set(seo.allowedContentFormats || []);
  const allowedStages = new Set(seo.allowedFunnelStages || []);
  const allowedVisualRequirements = new Set(seo.allowedVisualRequirements || []);
  const format = String(article.contentFormat || "").trim();
  if (!allowedFormats.has(format)) {
    errors.push(`contentFormat must be one of: ${[...allowedFormats].join(", ")}`);
    return;
  }
  if (String(article.formatReason || "").trim().length < seo.minimumFormatReasonCharacters) {
    errors.push(`formatReason must contain at least ${seo.minimumFormatReasonCharacters} characters`);
  }
  if (!allowedStages.has(article.funnelStage)) errors.push(`funnelStage must be one of: ${[...allowedStages].join(", ")}`);
  if (!String(article.conversionGoal || "").trim()) errors.push("conversionGoal is required");
  if (!allowedVisualRequirements.has(article.visualRequirement)) errors.push(`visualRequirement must be one of: ${[...allowedVisualRequirements].join(", ")}`);
  if (!nonEmptyStrings(article.requiredModules)) errors.push("requiredModules must be an array of non-empty strings");
  if (!nonEmptyStrings(article.variantDimensions)) errors.push("variantDimensions must be an array of non-empty strings");
  if (String(article.uniqueValue || "").trim().length < seo.minimumUniqueValueCharacters) errors.push(`uniqueValue must contain at least ${seo.minimumUniqueValueCharacters} characters`);
  if (format === "how_to") {
    if (!nonEmptyStrings(article.prerequisites) || article.prerequisites.length < 1) errors.push("how_to format requires prerequisites");
    if (!Array.isArray(article.steps) || article.steps.length < 3 || article.steps.some((step) => !step.title || !step.instruction)) errors.push("how_to format requires three ordered steps");
    if (!nonEmptyStrings(article.expectedOutcomes) || article.expectedOutcomes.length < 1) errors.push("how_to format requires expectedOutcomes");
    if (!nonEmptyStrings(article.troubleshooting) || article.troubleshooting.length < 1) errors.push("how_to format requires troubleshooting");
  }
  if (format === "comparison") {
    const comparison = article.comparison;
    if (!comparison || !nonEmptyStrings(comparison.items) || comparison.items.length < 2) errors.push("comparison format requires two compared items");
    if (!comparison || !nonEmptyStrings(comparison.criteria) || comparison.criteria.length < 2) errors.push("comparison format requires two criteria");
    if (!comparison || String(comparison.verdict || "").trim().length < 30) errors.push("comparison format requires a fit-based verdict");
  }
  if (format === "review") {
    if (String(article.reviewMethod || "").trim().length < 40) errors.push("review format requires a disclosed reviewMethod");
    if (!nonEmptyStrings(article.reviewEvidence) || article.reviewEvidence.length < 1) errors.push("review format requires reviewEvidence");
  }
  if (format === "structured_recommendation") {
    if (!nonEmptyStrings(article.recommendationCriteria) || article.recommendationCriteria.length < 2) errors.push("structured_recommendation requires recommendationCriteria");
    if (!nonEmptyStrings(article.recommendations) || article.recommendations.length < 2) errors.push("structured_recommendation requires recommendations");
  }
  if (format === "tool_landing_page") {
    if (!nonEmptyStrings(article.useCases) || article.useCases.length < 2) errors.push("tool_landing_page requires useCases");
    if (!nonEmptyStrings(article.examples) || article.examples.length < 1) errors.push("tool_landing_page requires examples");
    if (!nonEmptyStrings(article.variantDimensions) || article.variantDimensions.length < 1) errors.push("tool_landing_page requires variantDimensions");
  }
}

function validate(article, config, existing) {
  const errors = [];
  const warnings = [];
  const seo = config.seo;
  const evidence = config.evidence;
  const sourceIds = new Set((article.sources || []).map((source) => source.id));
  const text = bodyText(article);
  const textWords = words(text);
  const keyword = String(article.primaryKeyword || "");
  const keywordPattern = new RegExp(keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
  const keywordDensity = textWords.length ? (text.match(keywordPattern) || []).length / textWords.length : 0;

  for (const field of [
    "schemaVersion", "seoAuditVersion", "status", "slug", "category", "primaryKeyword", "intent",
    "contentFormat", "formatReason", "funnelStage", "conversionGoal", "visualRequirement",
    "contentDifferentiation", "uniqueValue", "title", "description", "excerpt", "author", "reviewer", "updatedAt",
  ]) {
    if (article[field] === undefined || article[field] === null || article[field] === "") {
      errors.push(`Missing required field: ${field}`);
    }
  }
  if (Number(article.seoAuditVersion) < 2) errors.push("seoAuditVersion must be 2 or higher");
  if (!["draft", "review", "approved"].includes(article.status)) errors.push("invalid status");
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(article.slug || "")) errors.push("slug must use lowercase kebab-case");
  if ((article.title || "").length < seo.titleMinCharacters || (article.title || "").length > seo.titleMaxCharacters) {
    errors.push(`title must be ${seo.titleMinCharacters}-${seo.titleMaxCharacters} characters`);
  }
  if ((article.description || "").length < seo.descriptionMinCharacters || (article.description || "").length > seo.descriptionMaxCharacters) {
    errors.push(`description must be ${seo.descriptionMinCharacters}-${seo.descriptionMaxCharacters} characters`);
  }
  if (
    article.primaryKeywordVariants !== undefined &&
    (!Array.isArray(article.primaryKeywordVariants) || article.primaryKeywordVariants.some((variant) => !String(variant).trim()))
  ) {
    errors.push("primaryKeywordVariants must be an array of non-empty strings");
  }
  if (!includesKeywordForm(article.title, article)) errors.push("title must include the primary keyword or an approved variant");
  if (!includesKeywordForm(openingText(article, seo.openingWordWindow), article)) {
    errors.push(`primary keyword must appear within the opening ${seo.openingWordWindow} words`);
  }
  if (!(article.sections || []).some((section) => includesKeywordForm(section.heading, article))) {
    errors.push("at least one section heading must include the primary keyword");
  }
  if (textWords.length < seo.minimumBodyWords) errors.push(`body requires at least ${seo.minimumBodyWords} words`);
  if (keywordDensity > seo.maximumPrimaryKeywordDensity) errors.push("primary keyword density exceeds the configured maximum");
  if ((article.sections || []).length < seo.minimumSections) errors.push(`requires at least ${seo.minimumSections} sections`);
  if ((article.faq || []).length < seo.minimumFaqItems) errors.push(`requires at least ${seo.minimumFaqItems} FAQ items`);
  if ((article.internalLinks || []).length < seo.minimumInternalLinks) errors.push(`requires at least ${seo.minimumInternalLinks} internal links`);

  const supporting = article.supportingKeywords || [];
  if (!Array.isArray(supporting) || supporting.length < seo.minimumSupportingKeywords || supporting.length > seo.maximumSupportingKeywords) {
    errors.push(`supportingKeywords must contain ${seo.minimumSupportingKeywords}-${seo.maximumSupportingKeywords} terms`);
  }
  for (const term of supporting) {
    if (keywordForms(article).some((form) => normalize(form) === normalize(term))) errors.push(`supporting keyword duplicates a primary keyword form: ${term}`);
    if (!includesPhrase(text, term)) errors.push(`supporting keyword is missing: ${term}`);
  }
  if (String(article.contentDifferentiation || "").trim().length < 40) {
    errors.push("contentDifferentiation must contain a specific overlap decision");
  }
  if (seo.requireFormatMetadata) validateFormat(article, seo, errors);

  const conclusion = (article.sections || []).at(-1);
  if (!/conclusion|bottom line|final take|next steps|what to do next/i.test(conclusion?.heading || "")) {
    errors.push("final section must be a conclusion or next-steps section");
  }
  if (!includesKeywordForm([conclusion?.heading, ...(conclusion?.paragraphs || [])].join(" "), article)) {
    errors.push("conclusion must include the primary keyword");
  }
  if (!(article.sections || []).some((section) => /limit|caveat|verify|uncertainty/i.test(section.heading || ""))) {
    errors.push("requires a limitations or verification section");
  }

  if ((article.sources || []).length < evidence.minimumSources) errors.push(`requires at least ${evidence.minimumSources} sources`);
  if ((article.sources || []).filter((source) => source.type === "primary").length < evidence.minimumPrimarySources) {
    errors.push(`requires at least ${evidence.minimumPrimarySources} primary source`);
  }
  for (const source of article.sources || []) {
    if (!source.id || !source.title || !source.publisher || !source.url || !hostname(source.url)) {
      errors.push("every source requires id, title, publisher, and a valid URL");
    }
    if (evidence.requireAccessDate && !source.accessedAt) errors.push(`source ${source.id || "(unknown)"} is missing accessedAt`);
    const domain = hostname(source.url);
    if (source.type === "primary" && (config.primaryDomains || []).length > 0 && !config.primaryDomains.some((allowed) => domain === allowed || domain.endsWith(`.${allowed}`))) {
      warnings.push(`primary source ${source.id} is outside configured primaryDomains`);
    }
  }
  for (const section of article.sections || []) {
    if (!Array.isArray(section.sourceIds) || section.sourceIds.length === 0) errors.push(`section "${section.heading}" requires sourceIds`);
    for (const id of section.sourceIds || []) if (!sourceIds.has(id)) errors.push(`section "${section.heading}" references unknown source ${id}`);
  }

  const ledger = article.claimLedger || [];
  if (!Array.isArray(ledger) || ledger.length === 0) errors.push("requires a non-empty claimLedger");
  const ledgerNumbers = new Set(ledger.flatMap((entry) => numericTokens(entry.claim)));
  for (const entry of ledger) {
    if (!entry.claim || !["factual", "numeric", "time-sensitive", "fictional"].includes(entry.type) || !["verified", "softened", "removed", "fictional"].includes(entry.action)) {
      errors.push("claimLedger entry has invalid claim, type, or action");
      continue;
    }
    if (entry.type === "fictional" || entry.action === "fictional") {
      if (entry.type !== "fictional" || entry.action !== "fictional") errors.push(`fictional claim "${entry.claim}" has inconsistent type/action`);
    } else {
      if (!entry.checkedAt) errors.push(`claim "${entry.claim}" is missing checkedAt`);
      if (entry.action === "removed") continue;
      if (!Array.isArray(entry.sourceIds) || entry.sourceIds.length === 0) errors.push(`claim "${entry.claim}" requires sourceIds`);
      for (const id of entry.sourceIds || []) if (!sourceIds.has(id)) errors.push(`claim "${entry.claim}" references unknown source ${id}`);
    }
  }
  for (const section of article.sections || []) {
    for (const paragraph of section.paragraphs || []) {
      if (/fictional|illustrative|invented/i.test(paragraph)) continue;
      for (const number of numericTokens(paragraph)) {
        if (!ledgerNumbers.has(number)) errors.push(`numeric claim ${number} in "${section.heading}" is missing from claimLedger`);
      }
    }
  }

  const audit = article.editorialAudit;
  if (!audit) errors.push("requires editorialAudit");
  else {
    for (const field of ["searchIntent", "contentDepth", "factCheck", "humanization"]) {
      if (audit[field] !== "pass") errors.push(`editorialAudit.${field} must be pass`);
    }
    if (!audit.auditedAt) errors.push("editorialAudit.auditedAt is required");
    if (String(audit.notes || "").trim().length < 20) errors.push("editorialAudit.notes must describe the review");
  }

  for (const blocked of config.blockedTopics || []) {
    if (new RegExp(`\\b${blocked.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i").test(text)) {
      errors.push(`blocked-topic match: ${blocked}`);
    }
  }
  for (const disclosure of config.requiredDisclosures || []) {
    if (!includesPhrase(text, disclosure)) errors.push(`missing required disclosure: ${disclosure}`);
  }
  for (const candidate of existing) {
    if (candidate.slug !== article.slug && normalize(candidate.primaryKeyword) === normalize(keyword)) {
      errors.push(`duplicate primary keyword with ${candidate.slug}`);
    }
  }
  if (article.status === "approved") {
    if (!article.publishedAt) errors.push("approved article requires publishedAt");
    if (config.publishing.requireNamedReviewer && (!article.reviewer || /pending/i.test(article.reviewer))) {
      errors.push("approved article requires a named reviewer");
    }
  }
  return { errors, warnings, words: textWords.length, keywordDensity };
}

async function checkUrls(sources, timeoutMs) {
  const results = [];
  for (const source of sources) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(source.url, {
        redirect: "follow",
        signal: controller.signal,
        headers: { "user-agent": "SEOKeywordArticleValidator/1.0", range: "bytes=0-1024" },
      });
      results.push({ id: source.id, status: response.status, passed: response.status >= 200 && response.status < 400 });
    } catch (error) {
      results.push({ id: source.id, status: null, passed: false, error: error instanceof Error ? error.message : String(error) });
    } finally {
      clearTimeout(timeout);
    }
  }
  return results;
}

function checkRendered(file, canonical) {
  const html = fs.readFileSync(file, "utf8");
  const errors = [];
  const h1Count = (html.match(/<h1\b/gi) || []).length;
  if (h1Count !== 1) errors.push(`rendered HTML has ${h1Count} H1 elements`);
  if (canonical && !html.includes(canonical)) errors.push(`rendered HTML is missing canonical ${canonical}`);
  if (/noindex/i.test(html)) errors.push("rendered approved page contains noindex");
  for (const type of ["Article", "BreadcrumbList", "FAQPage"]) {
    if (!html.includes(`"@type":"${type}"`) && !html.includes(`&quot;@type&quot;:&quot;${type}&quot;`)) {
      errors.push(`rendered HTML is missing ${type} structured data`);
    }
  }
  return errors;
}

const options = parseArgs(process.argv.slice(2));
const article = readJson(options.article);
const config = readJson(options.config);
const existing = loadExisting(options.existingDir);
const result = validate(article, config, existing);
console.log(`${result.errors.length === 0 ? "PASS" : "FAIL"} ${article.slug || path.basename(options.article)} (${result.words} words, keywordDensity=${result.keywordDensity.toFixed(4)})`);
for (const error of result.errors) console.log(`  ERROR: ${error}`);
for (const warning of result.warnings) console.log(`  WARN: ${warning}`);

if (options.checkUrls && result.errors.length === 0) {
  const urls = await checkUrls(article.sources || [], config.evidence.sourceRequestTimeoutMs || 15000);
  for (const item of urls) console.log(`${item.passed ? "PASS" : "FAIL"} source ${item.id}: ${item.error || `HTTP ${item.status}`}`);
  if (urls.some((item) => !item.passed)) result.errors.push("one or more source URLs are unreachable");
}
if (options.renderedHtml && result.errors.length === 0) {
  const renderedErrors = checkRendered(options.renderedHtml, options.canonical);
  for (const error of renderedErrors) console.log(`  ERROR: ${error}`);
  result.errors.push(...renderedErrors);
}
process.exit(result.errors.length === 0 ? 0 : 1);
