#!/usr/bin/env python3
"""Normalize CSV, TSV, or JSON keyword tables into a reusable task queue."""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from datetime import date
from pathlib import Path
from typing import Any


ALIASES = {
    "id": ["id", "taskid"],
    "priority": ["priority", "rank", "order"],
    "status": ["status", "state"],
    "primaryKeyword": ["primarykeyword", "primary_keyword", "keyword", "mainkeyword", "query"],
    "slug": ["slug", "urlslug", "path"],
    "category": ["category", "cluster", "topiccluster"],
    "intent": ["intent", "searchintent", "search_intent"],
    "supportingKeywords": [
        "supportingkeywords",
        "supporting_keywords",
        "secondarykeywords",
        "secondary_keywords",
        "relatedkeywords",
    ],
    "requiredAngles": ["requiredangles", "required_angles", "angles", "subtopics"],
    "parentPillar": ["parentpillar", "parent_pillar", "pillar", "hub"],
    "page": ["page", "targetpage", "target_page"],
    "pageType": ["pagetype", "page_type"],
    "topic": ["topic", "topicalcluster"],
    "volume": ["volume", "searchvolume", "search_volume"],
    "difficulty": ["keyworddifficulty", "keyword_difficulty", "difficulty", "kd"],
    "seedKeyword": ["seedkeyword", "seed_keyword"],
    "database": ["database", "country", "market"],
    "contentFormat": ["contentformat", "content_format", "format", "pageformat", "page_format"],
    "formatReason": ["formatreason", "format_reason"],
    "funnelStage": ["funnelstage", "funnel_stage", "stage"],
    "conversionGoal": ["conversiongoal", "conversion_goal", "goal"],
    "requiredModules": ["requiredmodules", "required_modules", "modules"],
    "visualRequirement": ["visualrequirement", "visual_requirement", "visuals"],
    "variantDimensions": ["variantdimensions", "variant_dimensions", "dimensions"],
}


def normalized_key(value: str) -> str:
    return re.sub(r"[^a-z0-9_]", "", str(value).strip().lower())


def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def split_list(value: Any) -> list[str]:
    if isinstance(value, list):
        items = value
    else:
        items = re.split(r"[|;]", str(value or ""))
    return [str(item).strip() for item in items if str(item).strip()]


def read_rows(path: Path) -> list[dict[str, Any]]:
    suffix = path.suffix.lower()
    if suffix == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        rows = data.get("tasks") if isinstance(data, dict) else data
        if not isinstance(rows, list):
            raise ValueError("JSON input must be an array or an object containing a tasks array")
        if not all(isinstance(row, dict) for row in rows):
            raise ValueError("Every JSON task row must be an object")
        return rows
    if suffix not in {".csv", ".tsv"}:
        raise ValueError("Supported input types are CSV, TSV, and JSON; export XLSX to CSV first")
    delimiter = "\t" if suffix == ".tsv" else ","
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter=delimiter))


def value_for(row: dict[str, Any], field: str) -> Any:
    normalized = {normalized_key(key): value for key, value in row.items()}
    for alias in ALIASES[field]:
        if normalized_key(alias) in normalized:
            return normalized[normalized_key(alias)]
    return None


def positive_int(value: Any, fallback: int) -> int:
    if value in (None, ""):
        return fallback
    parsed = int(str(value).strip())
    if parsed < 1:
        raise ValueError(f"priority must be positive, got {value!r}")
    return parsed


def number(value: Any, fallback: float = 0) -> float:
    if value in (None, ""):
        return fallback
    return float(str(value).replace(",", "").strip())


def first_intent(value: Any) -> str:
    return str(value or "informational").split(",", 1)[0].strip().lower() or "informational"


def category_for_topic(topic: str) -> str:
    value = topic.casefold()
    if "weather" in value:
        return "weather-ballparks"
    if "injur" in value:
        return "injuries-rosters"
    if "fantasy" in value or "scoring" in value:
        return "fantasy-baseball"
    if "optimizer" in value or "draftkings" in value or "fanduel" in value or "dfs" in value:
        return "dfs-strategy"
    return "projections-stats"


def format_for(intent: str, page_type: str, topic: str) -> str:
    """Infer a reviewable content format; explicit table values still win."""
    intent_value = str(intent or "informational").casefold()
    value = " ".join([page_type, topic]).casefold()
    if any(term in value for term in ["template", "tool", "calculator", "optimizer"]):
        return "tool_landing_page"
    if "comparison" in intent_value or any(term in value for term in ["comparison", "alternative"]):
        return "comparison"
    if "review" in value:
        return "review"
    if "commercial" in intent_value or "transactional" in intent_value:
        return "structured_recommendation"
    if "tutorial" in intent_value or "how-to" in intent_value or "how to" in intent_value:
        return "how_to"
    return "deep_explanation"


def infer_funnel_stage(intent: str) -> str:
    value = str(intent or "informational").casefold()
    if any(term in value for term in ["commercial", "transactional", "comparison"]):
        return "BOFU"
    if any(term in value for term in ["tutorial", "how-to", "how to"]):
        return "MOFU"
    return "TOFU"


def default_modules(content_format: str) -> list[str]:
    modules = {
        "deep_explanation": ["directAnswer", "originalAnalysis", "limitations", "internalLinks", "cta"],
        "how_to": ["directAnswer", "prerequisites", "steps", "expectedOutcomes", "troubleshooting", "faq", "cta"],
        "comparison": ["directAnswer", "comparisonTable", "criteria", "verdict", "faq", "cta"],
        "review": ["reviewMethod", "reviewEvidence", "limitations", "faq", "cta"],
        "structured_recommendation": ["selectionCriteria", "recommendations", "limitations", "faq", "cta"],
        "tool_landing_page": ["hero", "problem", "useCases", "examples", "features", "internalLinks", "cta"],
        "product_use_case": ["directAnswer", "useCases", "proof", "limitations", "cta"],
    }
    return modules.get(content_format, modules["deep_explanation"])


def page_group_tasks(rows: list[dict[str, Any]], site_id: str, excluded_topics: set[str], excluded_terms: list[str]) -> list[dict[str, Any]]:
    """Collapse keyword-strategy exports into one task per target Page."""
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        page = str(value_for(row, "page") or "").strip()
        if not page:
            raise ValueError("grouped keyword tables require a Page column")
        groups.setdefault(page, []).append(row)

    blocked_patterns = [re.compile(re.escape(term), re.IGNORECASE) for term in excluded_terms if term.strip()]
    candidates: list[dict[str, Any]] = []
    for page, group in groups.items():
        topic = str(value_for(group[0], "topic") or "").strip()
        searchable = " ".join(
            [page, topic, *[str(value_for(row, "primaryKeyword") or "") for row in group],
             *[str(value_for(row, "seedKeyword") or "") for row in group]],
        )
        if topic.casefold() in {item.casefold() for item in excluded_topics}:
            continue
        if any(pattern.search(searchable) for pattern in blocked_patterns):
            continue

        ranked = sorted(
            group,
            key=lambda row: (
                -number(value_for(row, "volume")),
                number(value_for(row, "difficulty"), 100),
                str(value_for(row, "primaryKeyword") or "").casefold(),
            ),
        )
        primary = ranked[0]
        primary_keyword = str(value_for(primary, "primaryKeyword") or "").strip()
        supporting = []
        for row in ranked[1:]:
            keyword = str(value_for(row, "primaryKeyword") or "").strip()
            if keyword and keyword.casefold() != primary_keyword.casefold() and keyword not in supporting:
                supporting.append(keyword)
            if len(supporting) == 5:
                break
        angles = []
        for row in ranked:
            angle = str(value_for(row, "seedKeyword") or "").strip()
            if angle and angle not in angles:
                angles.append(angle)
            if len(angles) == 5:
                break
        intents = []
        for row in group:
            intent = str(value_for(row, "intent") or "").strip().lower()
            if intent and intent not in intents:
                intents.append(intent)
        page_type = str(value_for(group[0], "pageType") or "Sub page").strip()
        primary_intent = first_intent(value_for(primary, "intent"))
        content_format = str(
            value_for(primary, "contentFormat") or format_for(primary_intent, page_type, topic)
        ).strip()
        task = {
            "id": f"{site_id}-{len(candidates) + 1:03d}",
            "priority": 0,
            "status": "queued",
            "primaryKeyword": primary_keyword,
            "slug": slugify(page),
            "targetPage": page,
            "category": category_for_topic(topic),
            "intent": primary_intent,
            "contentFormat": content_format,
            "formatReason": str(
                value_for(primary, "formatReason")
                or f"{content_format} matches the page type and {primary_intent} search intent."
            ).strip(),
            "funnelStage": str(
                value_for(primary, "funnelStage") or infer_funnel_stage(primary_intent)
            ).strip().upper(),
            "conversionGoal": str(
                value_for(primary, "conversionGoal")
                or ("start_optimizer" if content_format == "tool_landing_page" else "learn_and_apply")
            ).strip(),
            "requiredModules": split_list(value_for(primary, "requiredModules")) or default_modules(content_format),
            "visualRequirement": str(value_for(primary, "visualRequirement") or "optional").strip().lower(),
            "variantDimensions": split_list(value_for(primary, "variantDimensions")),
            "supportingKeywords": supporting,
            "requiredAngles": angles,
            "parentPillar": "/" if page_type.casefold() == "pillar page" else "/",
            "pageType": page_type,
            "topic": topic,
            "clusterSize": len(group),
            "clusterVolume": int(sum(number(value_for(row, "volume")) for row in group)),
            "primaryVolume": int(number(value_for(primary, "volume"))),
            "keywordDifficulty": int(number(value_for(primary, "difficulty"))),
            "intentVariants": intents,
        }
        candidates.append(task)

    candidates.sort(key=lambda task: (0 if task["pageType"].casefold() == "pillar page" else 1, -task["clusterVolume"], task["slug"]))
    for priority, task in enumerate(candidates, start=1):
        task["priority"] = priority
    return candidates


def normalize_row(row: dict[str, Any], index: int, site_id: str) -> dict[str, Any]:
    keyword = str(value_for(row, "primaryKeyword") or "").strip()
    if not keyword:
        raise ValueError(f"row {index} is missing primaryKeyword")
    slug = slugify(str(value_for(row, "slug") or keyword))
    task_id = str(value_for(row, "id") or f"{site_id}-{index:03d}").strip()
    task: dict[str, Any] = {
        "id": task_id,
        "priority": positive_int(value_for(row, "priority"), index),
        "status": str(value_for(row, "status") or "queued").strip().lower(),
        "primaryKeyword": keyword,
        "slug": slug,
        "category": str(value_for(row, "category") or "uncategorized").strip(),
        "intent": str(value_for(row, "intent") or "informational").strip().lower(),
    }
    supporting = split_list(value_for(row, "supportingKeywords"))
    angles = split_list(value_for(row, "requiredAngles"))
    pillar = str(value_for(row, "parentPillar") or "").strip()
    if supporting:
        task["supportingKeywords"] = supporting
    if angles:
        task["requiredAngles"] = angles
    if pillar:
        task["parentPillar"] = pillar
    task["contentFormat"] = str(
        value_for(row, "contentFormat")
        or format_for(task["intent"], str(value_for(row, "pageType") or ""), str(value_for(row, "topic") or ""))
    ).strip()
    task["formatReason"] = str(
        value_for(row, "formatReason") or f"{task['contentFormat']} matches the supplied search intent."
    ).strip()
    task["funnelStage"] = str(
        value_for(row, "funnelStage") or infer_funnel_stage(task["intent"])
    ).strip().upper()
    task["conversionGoal"] = str(value_for(row, "conversionGoal") or "learn_and_apply").strip()
    task["requiredModules"] = split_list(value_for(row, "requiredModules")) or default_modules(task["contentFormat"])
    task["visualRequirement"] = str(value_for(row, "visualRequirement") or "optional").strip().lower()
    task["variantDimensions"] = split_list(value_for(row, "variantDimensions"))
    return task


def load_existing(path: Path | None) -> list[dict[str, Any]]:
    if path is None:
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    tasks = data.get("tasks") if isinstance(data, dict) else None
    if not isinstance(tasks, list):
        raise ValueError("existing file must be an object containing a tasks array")
    return tasks


def validate_unique(tasks: list[dict[str, Any]]) -> None:
    checks = {
        "id": lambda task: str(task.get("id", "")).casefold(),
        "slug": lambda task: str(task.get("slug", "")).casefold(),
        "primaryKeyword": lambda task: str(task.get("primaryKeyword", "")).strip().casefold(),
    }
    for label, getter in checks.items():
        seen: dict[str, int] = {}
        for index, task in enumerate(tasks, start=1):
            value = getter(task)
            if not value:
                raise ValueError(f"task {index} is missing {label}")
            if value in seen:
                raise ValueError(f"duplicate {label} in tasks {seen[value]} and {index}: {value}")
            seen[value] = index


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="CSV, TSV, or JSON keyword table")
    parser.add_argument("--output", required=True, type=Path, help="Output tasks.json path")
    parser.add_argument("--site-id", default="seo", help="Prefix for generated task IDs")
    parser.add_argument("--existing", type=Path, help="Existing tasks.json to preserve and extend")
    parser.add_argument("--group-by-page", action="store_true", help="Create one task per Page group; auto-enabled when Page exists")
    parser.add_argument("--exclude-topic", action="append", default=[], help="Exclude an exact topic (repeatable)")
    parser.add_argument("--exclude-term", action="append", default=[], help="Exclude a term found in Page, Topic, Keyword, or Seed keyword (repeatable)")
    args = parser.parse_args()

    rows = read_rows(args.input)
    existing = load_existing(args.existing)
    grouped = args.group_by_page or any(value_for(row, "page") for row in rows)
    start = len(existing) + 1
    imported = (
        page_group_tasks(rows, args.site_id, set(args.exclude_topic), args.exclude_term)
        if grouped
        else [normalize_row(row, start + offset, args.site_id) for offset, row in enumerate(rows)]
    )

    existing_keywords = {str(task.get("primaryKeyword", "")).strip().casefold() for task in existing}
    existing_pages = {str(task.get("targetPage", "")).strip().casefold() for task in existing if task.get("targetPage")}
    new_tasks = []
    enriched = 0
    for task in imported:
        matching = next(
            (
                current
                for current in existing
                if str(current.get("targetPage", "")).strip().casefold() == task.get("targetPage", "").casefold()
                or str(current.get("primaryKeyword", "")).strip().casefold() == task["primaryKeyword"].casefold()
                or str(current.get("primaryKeyword", "")).strip().casefold() in {keyword.casefold() for keyword in task.get("supportingKeywords", [])}
            ),
            None,
        ) if grouped else None
        if matching:
            for key in [
                "targetPage", "pageType", "topic", "clusterSize", "clusterVolume", "primaryVolume",
                "keywordDifficulty", "intentVariants",
            ]:
                matching[key] = task[key]
            if not matching.get("contentFormat"):
                matching["contentFormat"] = format_for(
                    str(matching.get("intent") or task.get("intent") or "informational"),
                    str(matching.get("pageType") or task.get("pageType") or ""),
                    str(matching.get("topic") or task.get("topic") or ""),
                )
            matching.setdefault("formatReason", f"{matching['contentFormat']} matches the existing task intent and page type.")
            matching.setdefault("funnelStage", infer_funnel_stage(str(matching.get("intent") or task.get("intent") or "informational")))
            matching.setdefault("conversionGoal", "start_optimizer" if matching["contentFormat"] == "tool_landing_page" else "learn_and_apply")
            matching.setdefault("requiredModules", default_modules(matching["contentFormat"]))
            matching.setdefault("visualRequirement", "optional")
            matching.setdefault("variantDimensions", [])
            if not matching.get("supportingKeywords"):
                matching["supportingKeywords"] = task["supportingKeywords"]
            if not matching.get("requiredAngles"):
                matching["requiredAngles"] = task["requiredAngles"]
            enriched += 1
            continue
        if task["primaryKeyword"].casefold() in existing_keywords or task["slug"].casefold() in {str(item.get("slug", "")).casefold() for item in existing}:
            continue
        task["priority"] = len(existing) + len(new_tasks) + 1
        new_tasks.append(task)
    tasks = [*existing, *new_tasks]
    if grouped:
        for current in tasks:
            current.setdefault(
                "contentFormat",
                format_for(
                    str(current.get("intent") or "informational"),
                    str(current.get("pageType") or ""),
                    str(current.get("topic") or ""),
                ),
            )
            current.setdefault("formatReason", f"{current['contentFormat']} matches the task intent and page type.")
            current.setdefault("funnelStage", infer_funnel_stage(str(current.get("intent") or "informational")))
            current.setdefault("conversionGoal", "start_optimizer" if current["contentFormat"] == "tool_landing_page" else "learn_and_apply")
            current.setdefault("requiredModules", default_modules(current["contentFormat"]))
            current.setdefault("visualRequirement", "optional")
            current.setdefault("variantDimensions", [])
    validate_unique(tasks)
    payload = {"schemaVersion": 1, "updatedAt": date.today().isoformat(), "tasks": tasks}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"inputRows": len(rows), "groupedPages": len(imported) if grouped else None, "enriched": enriched, "added": len(new_tasks), "total": len(tasks), "output": str(args.output)}))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
