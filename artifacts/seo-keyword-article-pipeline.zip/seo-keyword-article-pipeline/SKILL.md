---
name: seo-keyword-article-pipeline
description: Turn CSV, TSV, JSON, or spreadsheet keyword tables into a prioritized SEO article queue and produce evidence-backed, text-first articles through deterministic SEO validation, search-intent differentiation, claim verification, editorial auditing, humanization, rendered technical checks, and controlled publication. Use when Codex receives a keyword list, content plan, SEO brief, article queue, or needs to install or run a reusable one-keyword-per-page content pipeline in any project.
---

# SEO Keyword Article Pipeline

## Inputs

Accept a keyword table plus the target project's site, source, output, and publishing configuration. For table columns and conversion commands, read `references/keyword-table.md`. For article fields and gates, read `references/article-contract.md`.

If the input is XLSX, use a spreadsheet-capable tool to inspect it and export the selected sheet to CSV before running the bundled importer. Do not infer rows from screenshots.

## Workflow

1. Check repository instructions and `git status`. Preserve an existing dirty-worktree policy.
2. Locate the project's content configuration, existing articles, internal routes, build commands, and publishing mechanism. Never replace a working project-specific workflow with a generic one.
3. Convert the supplied table into tasks with `scripts/import_keywords.py`. Preserve explicit priority; otherwise retain row order. Keep one primary keyword and one search intent per task. Infer a reviewable `contentFormat`, `funnelStage`, `conversionGoal`, `requiredModules`, `visualRequirement`, and `variantDimensions` from the intent and page type; an explicit table value wins.
4. Select exactly one task unless the user explicitly requests a batch. For recurring jobs, choose the highest-priority queued task.
5. Compare the keyword, title candidates, intent, and proposed headings with existing pages. Record a concrete `contentDifferentiation` statement. Exact keyword uniqueness alone is insufficient.
6. Create a compact task card: reader, content format, funnel stage, primary keyword, 3-5 supporting keywords, intent, conversion goal, required modules, required angles, exclusions, target length, and CTA.
7. Choose the format before drafting. Use `how_to` for procedural intent, `comparison` for explicit comparison intent, `review` only with first-hand evidence, `structured_recommendation` for commercial selection, `tool_landing_page` for tools/templates, and `deep_explanation` for informational questions. Treat community format heuristics as hypotheses, not universal ranking rules.
8. Build a format-specific outline before drafting. Make the title, opening, headings, FAQ, conclusion, and CTA answer the same search intent. Do not force a landing-page block, FAQ count, image, testimonial, or word count when the intent does not call for it.
9. Research checkable claims using current primary or authoritative sources. Create a claim ledger for numbers, dates, policies, prices, product capabilities, rules, rankings, and other volatile facts. Mark each claim verified, softened, removed, or explicitly fictional.
10. Draft in the target project's format. Default to text-first output. Add images only when the target configuration or user explicitly requires them; `visualRequirement: optional` never blocks publication.
11. Apply format-specific proof rules: how-to pages need prerequisites, ordered steps, expected outcomes, and troubleshooting; comparison pages need consistent criteria, a comparison table, and a fit-based conclusion; reviews need a disclosed method and first-hand evidence; recommendations need selection criteria and sourced rationale; tool/template pages need unique use cases, examples, and variant dimensions.
12. Put the primary keyword or an explicitly approved grammatical variant naturally in the title, opening 100 words, at least one section heading, and the conclusion. Cover supporting keywords where relevant; do not force exact-match repetition.
13. Include an original clearly labeled example, limitations or verification section, intent-matching FAQ items when useful, internal links, CTA, and an explicit conclusion or next-steps section.
14. Map every section and verified claim to real source IDs with access dates. Do not treat search snippets, invented citations, testimonials, or inaccessible pages as evidence.
15. Run the project's validator. If absent, use `scripts/validate_article.mjs` with `references/quality-gates.example.json`.
16. Run a semantic and format audit for search intent, format fit, heading usefulness, depth, FAQ relevance, trust, content differentiation, variant uniqueness, and content cannibalization. Resolve factual and high-impact issues first.
17. Humanize the corrected draft: remove mechanical cadence, filler, vague attribution, repeated templates, and unsupported promotion without changing facts, certainty, links, code, keywords, or CTA destinations.
18. Re-run deterministic validation and source reachability. After building, verify one H1, canonical, indexability, and Article, BreadcrumbList, and FAQPage structured data in rendered HTML when the project emits them.
19. Approve or publish only after every required gate passes. If evidence is insufficient, mark the task blocked with a specific reason.

## Portable commands

```bash
python3 "$SKILL_DIR/scripts/import_keywords.py" keywords.csv --output tasks.json --site-id example

node "$SKILL_DIR/scripts/validate_article.mjs" \
  article.json \
  --config "$SKILL_DIR/references/quality-gates.example.json" \
  --existing-dir content/blog

node "$SKILL_DIR/scripts/validate_article.mjs" \
  article.json \
  --config "$SKILL_DIR/references/quality-gates.example.json" \
  --existing-dir content/blog \
  --check-urls
```

Resolve `SKILL_DIR` to this skill's absolute directory before running commands.

## Publishing rule

Treat deterministic tests as necessary but not sufficient. A publishable result needs all of the following:

- no hard validation errors;
- no unresolved factual or intent findings;
- reachable cited sources;
- completed claim ledger and editorial audit;
- successful project tests/build;
- verified rendered SEO when applicable;
- a clean, project-approved publication path.

Return the selected keyword/task, differentiation decision, article path, source summary, validation commands with results, publication result, and any remaining risk.
